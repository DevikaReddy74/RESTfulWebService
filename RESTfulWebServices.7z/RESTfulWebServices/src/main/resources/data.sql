insert into Users values(1001, '2021-07-19T11:00:51.506+00:00','Dev');
insert into Users values(1002, '2020-07-19T11:00:51.506+00:00','Deva');
insert into Users values(1003, '2020-07-19T11:00:51.506+00:00','Devika');

insert into post values(2001,'my first post',1001);
insert into post values(2002,'my 2nd post',1001);
insert into post values(2003,'my first post',1002);